# Build the APK from an Android phone

This is an Android Studio/Gradle project and contains the web app in app/src/main/assets.

## Option A — Android Studio
1. Open this folder as an Android project.
2. Let Gradle sync.
3. Build > Build APK(s).
4. The debug APK will be under app/build/outputs/apk/debug/.

## Option B — Cloud Android builder
Upload this ZIP to a service that accepts Android Studio Gradle projects and build a debug APK.
Do not upload private information or signing keys.

The app itself is offline: it loads all learning content from bundled assets and stores progress in localStorage.
