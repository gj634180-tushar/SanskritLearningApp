const lessons=[
{name:"Swarāḥ — Vowels",desc:"Learn the basic Sanskrit vowels.",items:["अ — a","आ — ā","इ — i","ई — ī","उ — u","ऊ — ū","ऋ — ṛ","ए — e","ऐ — ai","ओ — o","औ — au"]},
{name:"Vyañjanāni — Consonants",desc:"Learn common Sanskrit consonants.",items:["क — ka","ख — kha","ग — ga","घ — gha","च — ca","ज — ja","ट — ṭa","त — ta","प — pa","म — ma","य — ya","र — ra","ल — la","व — va","स — sa","ह — ha"]},
{name:"Simple Words",desc:"Start understanding everyday Sanskrit.",items:["नमः — namaḥ — greetings","मित्रम् — mitram — friend","जलम् — jalam — water","फलम् — phalam — fruit","गृहम् — gṛham — house"]},
{name:"Simple Sentences",desc:"Make your first Sanskrit sentences.",items:["अहं पठामि — I read/study","अहं गच्छामि — I go","सः पठति — He reads","सा लिखति — She writes","तत् फलम् अस्ति — That is a fruit"]}
];
const words=[
["नमस्ते","namaste","Hello / Greetings","નમસ્તે"],["धन्यवादः","dhanyavādaḥ","Thank you","આભાર"],["जलम्","jalam","Water","પાણી"],["अन्नम्","annam","Food","ખોરાક"],["गृहम्","gṛham","House","ઘર"],["मित्रम्","mitram","Friend","મિત્ર"],["पुस्तकम्","pustakam","Book","પુસ્તક"],["विद्यालयः","vidyālayaḥ","School","શાળા"],["माता","mātā","Mother","માતા"],["पिता","pitā","Father","પિતા"],["सूर्यः","sūryaḥ","Sun","સૂર્ય"],["चन्द्रः","candraḥ","Moon","ચંદ્ર"],["शान्तिः","śāntiḥ","Peace","શાંતિ"],["प्रेम","prema","Love","પ્રેમ"],["ज्ञानम्","jñānam","Knowledge","જ્ઞાન"]
];
const quiz=[
["'जलम्' means…",["Water","Book","House","Friend"],0],
["Which is 'Mother'?",["पिता","माता","मित्रम्","गृहम्"],1],
["'अहं पठामि' means…",["I go","I read/study","He reads","She writes"],1],
["Which Sanskrit word means 'Peace'?",["प्रेम","ज्ञानम्","शान्तिः","जलम्"],2],
["'मित्रम्' means…",["Friend","School","Food","Moon"],0]
];
let state=JSON.parse(localStorage.getItem("sanskritState")||'{"done":[],"saved":[],"correct":0,"answered":0,"streak":0}');
function save(){localStorage.setItem("sanskritState",JSON.stringify(state));updateStats()}
function show(id){document.querySelectorAll(".screen").forEach(x=>x.classList.remove("active"));document.getElementById(id).classList.add("active");document.querySelectorAll("nav button").forEach(x=>x.classList.toggle("active",x.dataset.s===id));if(id==="lessons")renderLessons();if(id==="words")renderWords();if(id==="quiz")renderQuiz();if(id==="progress")renderProgress();updateStats()}
function updateStats(){document.getElementById("completed").textContent=state.done.length;document.getElementById("savedCount").textContent=state.saved.length;document.getElementById("streak").textContent=state.streak;document.getElementById("score").textContent=(state.answered?Math.round(state.correct/state.answered*100):0)+"%";document.getElementById("progressPct").textContent=Math.round(state.done.length/lessons.length*100)+"%"}
function renderLessons(){document.getElementById("lessonList").innerHTML=lessons.map((l,i)=>`<div class="lesson-card" onclick="openLesson(${i})"><div class="icon">${i===0?"🔤":i===1?"✍️":i===2?"📖":"🗣️"}</div><div><b>Lesson ${i+1}: ${l.name}</b><p>${l.desc}</p></div><span>${state.done.includes(i)?"✓":"›"}</span></div>`).join("")}
function openLesson(i){let l=lessons[i];document.getElementById("lessonList").innerHTML=`<div class="quiz-card"><h2>${l.name}</h2><p>${l.desc}</p>${l.items.map(x=>`<div class="word"><div class="sanskrit">${x.split(" — ")[0]}</div><p>${x.split(" — ").slice(1).join(" — ")}</p></div>`).join("")}<button class="primary" onclick="completeLesson(${i})">✓ Mark lesson complete</button></div>`;show("lessons")}
function completeLesson(i){if(!state.done.includes(i))state.done.push(i);state.streak=Math.max(1,state.streak);save();renderLessons();alert("Lesson completed! 🎉")}
function renderWords(){let q=(document.getElementById("search")?.value||"").toLowerCase();let arr=words.filter(w=>w.join(" ").toLowerCase().includes(q));document.getElementById("wordList").innerHTML=arr.map((w,i)=>`<div class="word"><button class="save" onclick="toggleSave(${words.indexOf(w)})">${state.saved.includes(words.indexOf(w))?"★":"☆"}</button><div class="sanskrit">${w[0]}</div><p><b>${w[1]}</b> • ${w[2]} • ${w[3]}</p></div>`).join("")}
function toggleSave(i){state.saved.includes(i)?state.saved=state.saved.filter(x=>x!==i):state.saved.push(i);save();renderWords()}
function renderQuiz(){let i=(state.answered)%quiz.length,q=quiz[i];document.getElementById("quizBox").innerHTML=`<div class="quiz-card"><p>Question ${i+1} of ${quiz.length}</p><div class="quiz-q">${q[0]}</div>${q[1].map((a,j)=>`<button class="quiz-option" onclick="answer(${i},${j})">${String.fromCharCode(65+j)}. ${a}</button>`).join("")}</div>`}
function answer(i,j){let q=quiz[i];state.answered++;if(j===q[2]){state.correct++;alert("Correct! 🎉")}else alert("Not quite. Correct answer: "+q[1][q[2]]);save();renderQuiz()}
function renderProgress(){let pct=Math.round(state.done.length/lessons.length*100);document.getElementById("progressRows").innerHTML=lessons.map((l,i)=>`<div class="progress-row"><b>Lesson ${i+1}</b> — ${l.name}<div class="bar"><i style="width:${state.done.includes(i)?100:0}%"></i></div></div>`).join("")}
function resetProgress(){if(confirm("Reset all learning progress?")){state={done:[],saved:[],correct:0,answered:0,streak:0};save();show("home")}}
show("home");