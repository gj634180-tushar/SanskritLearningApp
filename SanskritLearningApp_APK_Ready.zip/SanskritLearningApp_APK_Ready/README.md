# Sanskrit Learning App – Version 1

A simple offline Sanskrit learning web app designed for Android phones.

## Features
- Sanskrit alphabet: स्वर and व्यञ्जन
- Beginner vocabulary with English and Gujarati meanings
- Daily lessons
- Multiple-choice quiz
- Progress tracking
- Saved/favorite words
- Offline-first design using localStorage
- Mobile-friendly interface

## Run
Open `index.html` in a browser. It works offline after the files are copied to the phone.

## Android APK
This source is structured as a simple single-folder web app. To make a true APK, import the folder into an Android WebView/Capacitor project or an Android wrapper/build service.
